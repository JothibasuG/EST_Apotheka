<?php
// Check if the form was submitted with the patient ID
// Author: G.Jothibasu

if (isset($_POST['patient_id'])) {
    // Get the patient ID from the form
    $patient_id = $_POST['patient_id'];

    // Include the mPDF library
    require_once __DIR__ . '/vendor/autoload.php';

    // Create an mPDF instance
    $mpdf = new \Mpdf\Mpdf();

    // Your HTML content for the PDF (replace with your content)
    $html = '<html><body><h1>Patient Consent Form : PCF </h1>';
    $html .= '<p>Patient ID: ' . $patient_id . '</p>';
    $html .= '<p>Consent form content goes here.</p>';
    $html .= '</body></html>';

    try {
        // Write HTML content to the PDF
        $mpdf->WriteHTML($html);

        // Output the PDF to the browser
        $mpdf->Output();

        // Exit to prevent further processing
        exit;
    } catch (\Mpdf\MpdfException $e) {
        echo 'An error occurred: ' . $e->getMessage();
    }
} else {
    // Handle the case where the form was not submitted with a patient ID
    echo 'Please enter a valid patient ID.';
}
?>
