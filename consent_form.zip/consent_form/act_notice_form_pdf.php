<?php
// Author: G.Jothibasu
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Include necessary libraries and set up error reporting

require_once("../../globals.php");
require_once $GLOBALS['vendor_dir'] . "/mpdf_2/vendor/autoload.php";

use OpenEMR\Core\Header;

if (isset($_GET['set_pid'])) {
    include_once("$srcdir/pid.inc");
    setpid($_GET['set_pid']);
}

$patient_id = $_SESSION['pid'];

// if (isset($_SESSION['pid'])) {
if (isset($_GET['generate_pdf'])) {
    $patient_id = $_SESSION['pid'];

    // Retrieve patient data from patient_data table
    $patient_data = sqlStatement("SELECT fname FROM patient_data WHERE pid = '$patient_id'");

    // Check if patient data is found in patient_data table
    if ($patient_data && sqlNumRows($patient_data) > 0) {
        $patient_row = sqlFetchArray($patient_data);

        // Populate the form fields with patient_data
        $fname = $patient_row['fname'];
        
    } else {
        // Handle the case where patient data is not found in patient_data table
        echo "Patient data not found!";
        exit; // Exit to prevent further processing
    }

    // Retrieve patient act notice from patient_consent_form table
    $patient_act = sqlStatement("SELECT * FROM patient_act_notice WHERE patient_id = '$patient_id'");

    // Check if patient act notice is found in patient_consent_form table
    if ($patient_act && sqlNumRows($patient_act) > 0) {
        // patient act notice is found, populate the form fields from patient_consent_form
        $patient_act_row = sqlFetchArray($patient_act);
        $act_sign = $patient_act_row['act_sign'];
        $act_date_signed = $patient_act_row['act_date_signed'];
     
    } else {
       
        echo "Patient ACT Notice form data not found!";
    }
   
   
    // $documentRoot = $_SERVER['DOCUMENT_ROOT'];
    // $fullPath = '/sites/default/documents/patient_consent_form/' ;
    // $fileLocation = $documentRoot .$fileLocation . $fileName;
    
    // Define the file path for server storage
    $documentRoot = $_SERVER['DOCUMENT_ROOT'];
    $fullPath = '/sites/default/documents/patient_consent_form/';
    $fileLocation = $documentRoot . $fullPath . $fileName;
    
    // Create mPDF object with zero margins and no headers/footers
    $mpdf = new \Mpdf\Mpdf([
      'mode' => 'utf-8',
      'margin_left' => 0,
      'margin_right' => 0,
      'margin_top' => 0,
      'margin_bottom' => 0,
      'margin_header' => 0,
      'margin_footer' => 0,
    ]);

    // Add a new page (full page size)
    $mpdf->AddPage();
    
    $mpdf->SetTitle('');
    $mpdf->SetAuthor('G.Jothibasu');

    $html ='<html>
    <head>
    

        <style>
            body {
                font-family: "Roboto", sans-serif;
                padding: 0;
                margin: 0;
            }
    
            h1 {
                margin: 0;
            }
    
            p {
                margin: 0;
            }
    
            .x-list li {
                position: relative;
            }
    
            .x-list li::before {
                content: "\2022";
                color: #b2bb1e;
                font-size: 30px;
                display: inline-block;
                position: absolute;
                left: -19px;
                top: -8px;
            }
        </style>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

</head>
<body>
    <div>
        <div style="display:flex; justify-content: space-between; margin: 0px 30px; padding-bottom: 10px;">
          <div>
            <h4
              style="font-family: "Roboto", sans-serif; font-size: 12px; letter-spacing: 0px; line-height: 27px; color: #005596; font-weight: bold; margin-bottom: 10px;">
              PATIENT CONSENT FORM</h4>
            <img src="images/logo.png" style="width: 200px;" />
          </div>
          <div style="text-align: right;">
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Genentech-Access.com</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Phone: <span style="color: #000;">(866) 422-2377 </span>&nbsp;&nbsp;
              Fax: <span style="color: #000;">(866) 480-7762</span></p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500; margin-bottom: 5px;">
              6 a.m.–5 p.m. (PT) M-F</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              M-US-00002802(v2.0)</p>
          </div>
        </div>
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px; ">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Sample Title Here</h2>
        </div>
    
        
    
        <div style="background-color: #005596; height: 2px; margin: 0px 30px; margin-bottom: 5px;"></div>
    
        <div style="margin: 0px 30px;">
          <p style="font-size: 16px; color: #292829;">Genentech can start supporting you when <b>page 3</b> of this form is
            submitted by you or your
            doctor’s office in
            one of the following ways:</p>
        </div>
    
        
        <div style="margin: 0px 30px; padding-top: 5px;">
          <p style="font-size: 16px;  color: #292829;">A representative from Genentech Access Solutions or your doctor’s
            office will call you to tell
            you about your coverage,
            costs and support for your treatment.</p>
        </div>
    
        <div style="padding: 0px 0px; margin: 10px 0px 15px 0px; background-color: #e2e5b7;">
          <p style="padding: 5px 0px;">
            <span
              style="font-size: 14px; letter-spacing: 0px; color: #005596; font-family: "Roboto", sans-serif; padding-left: 30px; font-weight: 500; padding-right: 10px;">
              If you have any questions, talk to your health care provider or call Genentech Access Solutions at (866)
              422-2377.
            </span>
          </p>
        </div>
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px; display:none;">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Helpful Terminology</h2>
        </div>
    
       
    
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px;">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Terms and Conditions of the Genentech
            Patient Foundation</h2>
        </div>
    
        <div style="margin: 0px 30px;;">
          <ul style="padding-left: 25px; margin-bottom: 0px; margin-top: 10px;" class="x-list">
            <li style="font-size: 14px; margin-bottom: 10px;color: #000000; display: block;">
              If I receive free medicine from the Genentech Patient Foundation, I will not sell or give out the medicine
              because it is
              illegal to do so. I am responsible to ensure that the medicine is sent to a secure address when shipped to me,
              and I
              must control any medicine that I receive
            </li>
            <li style="font-size: 14px; margin-bottom: 10px;color: #000000; display: block;">
              I understand that, for purposes of an audit, the Genentech Patient Foundation may ask me for a copy of my IRS
              1040 form or other proof of income
            </li>
          </ul>
        </div>
    
      </div>
    
      <!-- <div style="margin: 20px 0px;"> -->
      
      <div>
        
        <div style="margin: 0px 30px; display: flex;  border-top: 0px solid #005596; border-left: 2px solid #005596;
        border-right: 2px solid #005596; border-bottom: 2px solid #005596;  margin-bottom: 5px;">
          <div style="background-color: #e2e5b7; width: 8%; position: relative;">
            <div
              style=" 
              position: absolute; left: 30%; bottom: 0; transform: rotate(-90deg);  transform-origin: 0 0;color: #005596; font-size: 18px; margin-right: 5px; font-weight: 500;">
              <span>REQUIRED</span>
            </div>
          </div>
          <div style="padding: 5px 5px 5px 0px; width: 92%;">
            <div style="display: flex;">
              <p style="position: relative; display: flex; align-self: center; width: 20%;">
                <img src="images/icon6.png" style="position: relative; width: 130px; height: 60px;" />
                <span style="position: absolute; left: 0; top:10px; color: #ffffff; font-weight: 500; font-size: 17px; padding-left: 5px;">Sign
                  and <br /> date here</span>
              </p>
              <div style="width: 80%; margin-left: 5px;">
                <span style="width: 96%; height: 25px; border-top: 0px;  border-left: 0px;         margin-right: 10px;" > ' . htmlspecialchars($act_sign) . '</span>
                <p style="color: #ed1d24; font-size: 16px;  font-weight: 500; letter-spacing: 0px;
                margin: 0;  padding: 0;  ">  *Signature of Patient/Legally Authorized Representative</p>
                <p style="color: #000;
              font-size: 14px;
              font-weight: 500;
            ">(A parent or guardian must sign for patients under 18 years of age)</p>
              </div>
              <div style="width: 20%;">
                <span style="display: flex; width: 100%; height: 25px;  border-bottom: 1px solid #000000;">
                 
                <span style="height: 22px;  border:0px; width: 50%;" > ' . htmlspecialchars($act_date_signed) . '</span>
                </span>
                <p style="color: #ed1d24; font-size: 18px;  font-weight: 500;">*Date signed</p>
                <p style="color: #000; font-size: 15px;  font-weight: 500;letter-spacing: 0px; ">(MM/DD/YYYY)</p>
              </div>
            </div>
    
            </div>
    
    
          </div>
        </div>
    
    
       
      </div>
    
    </body>
  </html>' ;

$mpdf->WriteHTML($html);

try {
    // Output the PDF and save it to the specified file location
    $mpdf->Output($fileLocation, 'F'); // 'F' saves the PDF to a file

    // Provide a download link for the user
    echo 'Update and PDF : <a href="' . $fileLocation . '" download>' . $fileName . '</a>';
} catch (\Mpdf\MpdfException $e) {
    echo 'An error occurred: ' . $e->getMessage();
}
}
// Your HTML content for the PDF
$html = '<html>Your HTML content goes here</html>';

// Specify the file location where you want to save the PDF with the patient ID in the file name
$fileName = 'patient_consent_form_' . $patient_id . '.pdf';
// $fileLocation = '../../../sites/default/documents/patient_consent_form/' . $fileName;
// $documentRoot = $_SERVER['DOCUMENT_ROOT'];
// $fullPath = '/sites/default/documents/patient_consent_form/';
// $fileLocation = $documentRoot . $fullPath . $fileName;
$documentRoot = $_SERVER['DOCUMENT_ROOT'];
$file_location = '/sites/default/documents/patient_consent_form/'; // Define the file location
$serverFileLocation = $documentRoot . $file_location . $fileName;
$mpdf->Output($serverFileLocation, 'F'); // 'F' saves the PDF to a file

// Now you can use $fullPath as your file location

try {
    // Add headers and footers
    $mpdf->SetHeader('Welcome to all'); // Set your header content
    $mpdf->SetFooter('Footer text'); // Set your footer content

    // Write HTML content to the PDF
    $mpdf->WriteHTML($html);

    // Output the PDF to the browser
    $mpdf->Output($fileLocation, 'I'); // 'I' sends the PDF inline to the browser
    // Update the database with file_location and file_name
    // if (isset($_SESSION['pid'])) {
    //   $patient_id = $_SESSION['pid'];
    //   $update_file_query = "UPDATE patient_consent_form SET file_location = ?, file_name = ? WHERE patient_id = ?";
    //   $update_file_params = array($fileLocation, $fileName, $patient_id);
    //   sqlStatement($update_file_query, $update_file_params);

      if (isset($_SESSION['pid'])) {
        $patient_id = $_SESSION['pid'];
        $update_file_query = "UPDATE patient_act_notice SET act_file_location = ?, act_file_name = ? WHERE patient_id = ?";
        $update_file_params = array($file_location . $fileName, $fileName, $patient_id);
        sqlStatement($update_file_query, $update_file_params);
    }
    exit;
  }
 catch (\Mpdf\MpdfException $e) {
  echo 'An error occurred: ' . $e->getMessage();
}
exit;

?>
<!DOCTYPE html>
<html lang="en">

<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $fname; ?> Patient Consent Form (<?php echo $patient_id; ?>)</title>
    <style>
    /* Add CSS styles here */
    </style>
</head>

<body>
    <!--  HTML content goes here -->
</body>

</html>

