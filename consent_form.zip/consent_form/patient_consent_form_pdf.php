<?php
// Include necessary libraries and set up error reporting
// Author: G.Jothibasu
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once("../../globals.php");
require_once $GLOBALS['vendor_dir'] . "/mpdf_2/vendor/autoload.php";

use OpenEMR\Core\Header;

if (isset($_GET['set_pid'])) {
    include_once("$srcdir/pid.inc");
    setpid($_GET['set_pid']);
}

$patient_id = $_SESSION['pid'];

// if (isset($_SESSION['pid'])) {
if (isset($_GET['generate_pdf'])) {
    $patient_id = $_SESSION['pid'];

    // Retrieve patient data from patient_data table
    $patient_data = sqlStatement("SELECT fname, lname, DOB, phone_home, phone_cell, email FROM patient_data WHERE pid = '$patient_id'");

    // Check if patient data is found in patient_data table
    if ($patient_data && sqlNumRows($patient_data) > 0) {
        $patient_row = sqlFetchArray($patient_data);

        // Populate the form fields with patient_data
        $fname = $patient_row['fname'];
        $lname = $patient_row['lname'];
        $dob = $patient_row['DOB'];
        $phone_home = $patient_row['phone_home'];
        $phone_cell = $patient_row['phone_cell'];
        $email = $patient_row['email'];
    } else {
        // Handle the case where patient data is not found in patient_data table
        echo "Patient data not found!";
        exit; // Exit to prevent further processing
    }

    // Retrieve consent form data from patient_consent_form table
    $consent_form_data = sqlStatement("SELECT * FROM patient_consent_form WHERE patient_id = '$patient_id'");

    // Check if consent form data is found in patient_consent_form table
    if ($consent_form_data && sqlNumRows($consent_form_data) > 0) {
        // Consent form data is found, populate the form fields from patient_consent_form
        $consent_form_row = sqlFetchArray($consent_form_data);
        $ok_leave = $consent_form_row['ok_leave'];
        $preferred_language = $consent_form_row['preferred_language'];
        $other_language = $consent_form_row['other_language'];
        $alter_contact = $consent_form_row['alter_contact'];
        $relationship = $consent_form_row['relationship'];
        $p_phone = $consent_form_row['p_phone'];
        $household_size = $consent_form_row['household_size'];
        $annual_household_income = $consent_form_row['annual_household_income'];
        $cpri = $consent_form_row['cpri'];
        $tcpac = $consent_form_row['tcpac'];
        $sign = $consent_form_row['sign'];
        $date_signed = $consent_form_row['date_signed'];
        $p_fname = $consent_form_row['p_fname'];
        $p_lname = $consent_form_row['p_lname'];
        $r_patient = $consent_form_row['r_patient'];
    } else {
       
        echo "Consent form data not found!";
    }
    if ($ok_leave == 1) {
      echo 'Result will appear: ' . htmlspecialchars($ok_leave);
    } else {
     
    }
    $fontSize = '22px'; // You can adjust this value to control the size
    $colorForCheck = 'Green'; // Color for checkmark when the PHP value is 1
    $colorForCross = 'Red';   // Color for cross when the PHP value is 0

    // Define boxed checkmark and boxed cross characters with increased font size and color
    $boxedCheckmark = '<span style="font-size: ' . $fontSize . '; color: ' . $colorForCheck . ';">&#9745;</span>'; // U+2611
    $boxedCross = '<span style="font-size: ' . $fontSize . '; color: ' . $colorForCross . ';">&#9746;</span>';     // U+2612

    $leaveSymbol = ($ok_leave == 1) ? $boxedCheckmark : $boxedCross;
    $cpriSymbol = ($cpri == 1) ? $boxedCheckmark : $boxedCross;
    $tcpacSymbol = ($tcpac == 1) ? $boxedCheckmark : $boxedCross;

    $fileName = 'patient_consent_form_' . $patient_id . '.pdf';
    $file_location = '../../../sites/default/documents/patient_consent_form/' . $fileName;
    // $documentRoot = $_SERVER['DOCUMENT_ROOT'];
    // $fullPath = '/sites/default/documents/patient_consent_form/' ;
    // $fileLocation = $documentRoot .$fileLocation . $fileName;
    
    // Define the file path for server storage
    $documentRoot = $_SERVER['DOCUMENT_ROOT'];
    $fullPath = '/sites/default/documents/patient_consent_form/';
    $fileLocation = $documentRoot . $fullPath . $fileName;
    
    // Create mPDF object with zero margins and no headers/footers
    $mpdf = new \Mpdf\Mpdf([
      'mode' => 'utf-8',
      'margin_left' => 0,
      'margin_right' => 0,
      'margin_top' => 0,
      'margin_bottom' => 0,
      'margin_header' => 0,
      'margin_footer' => 0,
    ]);

    // Add a new page (full page size)
    $mpdf->AddPage();
    
    $mpdf->SetTitle('');
    $mpdf->SetAuthor('G.Jothibasu');

    $html ='<html>
    <head>
    

        <style>
            body {
                font-family: "Roboto", sans-serif;
                padding: 0;
                margin: 0;
            }
    
            h1 {
                margin: 0;
            }
    
            p {
                margin: 0;
            }
    
            .x-list li {
                position: relative;
            }
    
            .x-list li::before {
                content: "\2022";
                color: #b2bb1e;
                font-size: 30px;
                display: inline-block;
                position: absolute;
                left: -19px;
                top: -8px;
            }
        </style>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

</head>
<body>
    <div>
        <div style="display:flex; justify-content: space-between; margin: 0px 30px; padding-bottom: 10px;">
          <div>
            <h4
              style="font-family: "Roboto", sans-serif; font-size: 12px; letter-spacing: 0px; line-height: 27px; color: #005596; font-weight: bold; margin-bottom: 10px;">
              PATIENT CONSENT FORM</h4>
            <img src="images/logo.png" style="width: 200px;" />
          </div>
          <div style="text-align: right;">
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Genentech-Access.com</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Phone: <span style="color: #000;">(866) 422-2377 </span>&nbsp;&nbsp;
              Fax: <span style="color: #000;">(866) 480-7762</span></p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500; margin-bottom: 5px;">
              6 a.m.–5 p.m. (PT) M-F</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              M-US-00002802(v2.0)</p>
          </div>
        </div>
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px; ">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Sample Title Here</h2>
        </div>
    
        <div style="display: flex; margin-top: 15px; ">
          <div style="width: 45%; display:none;">
            <p style="background-color: #e2e5b7; display: inline; padding: 5px 0px;">
              <span
                style="font-size: 16px; letter-spacing: 0px; line-height: 26px; color: #005596; font-family: "Roboto", sans-serif; padding-left: 30px; font-weight: 500; padding-right: 10px;">
                By completing this form, you can:
              </span>
            </p>
    
            <div style="display: flex; padding-left: 30px; align-items: center; margin: 10px 0px;">
              <img src="images/icon1.png" style="width: 50px; height: 50px;;" />
              <p
                style="padding-left: 30px; font-size: 14px; letter-spacing: 0px; color: #000000; font-family: "Roboto", sans-serif;">
                Learn about your health insurance coverage and other options to get your Genentech medicine</p>
            </div>
            <div style="display: flex; padding-left: 30px; align-items: center; margin: 10px 0px;">
              <img src="images/icon2.png" style="width: 50px; height: 50px;;" />
              <p
                style="padding-left: 20px; font-size: 14px; letter-spacing: 0px; color: #000000; font-family: "Roboto", sans-serif;">
                Sign up to receive <b>optional</b> disease education and other material</p>
            </div>
          </div>
    
          <div style="width: 45%; margin-right: 30px; display:none;">
            <p style="font-size: 16px; letter-spacing: 0px; line-height: 26px; color: #000; font-family: "Roboto", sans-serif; padding-left: 20px; font-weight: 500;
               padding-right: 10px; padding-bottom: 5px;">
              Please follow these 3 steps to get started:</p>
    
            <div style="display: flex; padding-left: 20px; align-items: center; margin-bottom: 5px;">
              <div
                style="font-size: 22px; letter-spacing: 0px; line-height: 35px; color: #b2bb1e; font-family: "Roboto", sans-serif; font-weight: 600; margin-right: 5px;">
                1. </div>
              <div>
                <p style="font-size: 14px; letter-spacing: 0px; color: #000000; font-family: "Roboto", sans-serif;">
                  Read “Authorization to Use and Disclose Personal Information” on page 2.
                </p>
              </div>
            </div>
    
            <div style="display: flex; padding-left: 20px; align-items: center; margin-bottom: 5px;">
              <div
                style="font-size: 22px; letter-spacing: 0px; line-height: 35px; color: #b2bb1e; font-family: "Roboto", sans-serif; font-weight: 600; margin-right: 5px;">
                2. </div>
              <div>
                <p style="font-size: 14px; letter-spacing: 0px; color: #000000; font-family: "Roboto", sans-serif;">
                  Sign and date page 3. Please note you must sign the form to get support for your treatment. </p>
              </div>
            </div>
    
            <div style="display: flex; padding-left: 20px; align-items: center; margin-bottom: 5px;">
              <div
                style="font-size: 22px; letter-spacing: 0px; line-height: 35px; color: #b2bb1e; font-family: "Roboto", sans-serif; font-weight: 600; margin-right: 5px;">
                3. </div>
              <div>
                <p style="font-size: 14px; letter-spacing: 0px; color: #000000; font-family: "Roboto", sans-serif;">
                  Send in your completed form using one of the options below
                </p>
              </div>
            </div>
          </div>
        </div>
    
        <div style="background-color: #005596; height: 2px; margin: 0px 30px; margin-bottom: 5px;"></div>
    
        <div style="margin: 0px 30px;">
          <p style="font-size: 16px; color: #292829;">Genentech can start supporting you when <b>page 3</b> of this form is
            submitted by you or your
            doctor’s office in
            one of the following ways:</p>
        </div>
    
        <div
          style="display: flex; justify-content: space-between; align-items: center; align-self:center; margin: 0px 30px;">
          <div style="display: flex; align-items: center; align-self:center; width: 35%;">
            <img src="images/QR.jpg" style="height: 80px; width: 80px;" />
            <p style="font-size: 14px; margin-left: 10px;
          letter-spacing: 0px;
          color: #000000;">Complete online by <br />
              scanning this QR code <br />
              or visiting <br />
              Genentech-Access.com/<br />
              PatientConsent</p>
          </div>
    
          <div style="border-left: 1px solid #005596; height: 100px; display: flex; align-items: center;">
            <p
              style="width: 25px; height: 25px; border-radius: 18px;  background-color: #ffffff; border: 1px solid #005596; margin-left: -14px;">
              <span
                style="font-size: 10px; position: relative; left: 6px;   right: 0;  top: -1px; line-height: 26px; color: #005596; font-weight: 500;">OR</span>
            </p>
          </div>
    
          <div style="display: flex; align-items: center; align-self:center; width: 28%;">
            <img src="images/icon4.png" style="height: 60px; width: 60px;" />
            <p style="font-size: 14px; margin-left: 10px; letter-spacing: 0px; color: #000000;">Print, complete, take <br />
              a
              photo and text it to <br />(650) 877-1111</p>
          </div>
    
          <div style="border-left: 1px solid #005596; height: 100px; display: flex; align-items: center;">
            <p
              style="width: 25px; height: 25px; border-radius: 18px;  background-color: #ffffff; border: 1px solid #005596; margin-left: -14px;">
              <span
                style="font-size: 10px; position: relative; left: 6px;   right: 0;  top: -1px; line-height: 26px; color: #005596; font-weight: 500;">OR</span>
            </p>
          </div>
    
    
          <div style="display: flex; align-items: center; align-self:center; width: 28%;">
            <img src="images/icon5.png" style="height: 60px; width: 60px;" />
            <p style="font-size: 14px; margin-left: 10px; letter-spacing: 0px; color: #000000;">Print, complete <br /> and
              fax it
              to <br /> (866) 480-7762</p>
          </div>
    
        </div>
    
        <div style="margin: 0px 30px; padding-top: 5px;">
          <p style="font-size: 16px;  color: #292829;">A representative from Genentech Access Solutions or your doctor’s
            office will call you to tell
            you about your coverage,
            costs and support for your treatment.</p>
        </div>
    
        <div style="padding: 0px 0px; margin: 10px 0px 15px 0px; background-color: #e2e5b7;">
          <p style="padding: 5px 0px;">
            <span
              style="font-size: 14px; letter-spacing: 0px; color: #005596; font-family: "Roboto", sans-serif; padding-left: 30px; font-weight: 500; padding-right: 10px;">
              If you have any questions, talk to your health care provider or call Genentech Access Solutions at (866)
              422-2377.
            </span>
          </p>
        </div>
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px; display:none;">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Helpful Terminology</h2>
        </div>
    
        <div style="display: flex; margin: 0px 30px; display:none;">
          <div style="width: 40%; margin: 10px 0px; padding-right: 20px;">
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Genentech:</b></span>
              The maker of the medicine your doctor
              wants to prescribe for you. Genentech is committed to
              helping patients get the medicine their doctor prescribed.
              When used on this form, the term “Genentech” refers
              to Genentech, Genentech Patient Foundation, and their
              respective partners, affiliates, subcontractors and agents.
            </p>
    
            <p style="font-size: 14px; margin-bottom: 10px;
              color: #000000;">
              <span style=" color: #005596;"><b>Genentech Access Solutions:</b></span>
              A team at Genentech that
              works with your doctor and health insurance plan to help
              you get your medicine.
            </p>
    
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Genentech Patient Foundation:</b></span>
              A program that gives free
              Genentech medicine to eligible people who don t have
              insurance coverage or who have financial concerns.
            </p>
    
            <p style="font-size: 14px;
            color: #000000;">
              <span style=" color: #005596;"><b>Annual household income:</b></span>
              How much you and the members
              of your household currently make each year, minus specific
              deductions. This is also frequently referred to as your adjusted
              gross income or AGI. This information is needed to determine
              Genentech Patient Foundation eligibility.
            </p>
    
    
          </div>
          <div style="width: 45%; margin: 10px 0px; display:none;">
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Household size:</b></span>
              Number of people living in your household, including you.
            </p>
    
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Deductible:</b></span>
              The amount you pay for health care services
              or medicines out of pocket before your health insurance
              plan begins to pay.
            </p>
    
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Out-of-pocket costs:</b></span>
              The amount not paid by the
              insurance plan that you must pay for your treatment.
              This includes deductibles, co-pays and co-insurance.
            </p>
    
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Co-pay assistance:</b></span>
              Programs available to help eligible
              patients pay for their medicines.
            </p>
    
            <p style="font-size: 14px; margin-bottom: 10px;
            color: #000000;">
              <span style=" color: #005596;"><b>Alternate contact:</b></span>
              Someone you choose to be your contact
              person if Genentech Access Solutions cannot reach you.
            </p>
    
            <p style="font-size: 14px; 
            color: #000000;">
              <span style=" color: #005596;"><b>Legally authorized representative:</b></span>
              An individual or judicial
              or other body authorized under applicable law to consent on
              behalf of a patient (e.g., parent or legal guardian of a minor).
            </p>
          </div>
        </div>
    
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px;">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Terms and Conditions of the Genentech
            Patient Foundation</h2>
        </div>
    
        <div style="margin: 0px 30px;;">
          <ul style="padding-left: 25px; margin-bottom: 0px; margin-top: 10px;" class="x-list">
            <li style="font-size: 14px; margin-bottom: 10px;color: #000000; display: block;">
              If I receive free medicine from the Genentech Patient Foundation, I will not sell or give out the medicine
              because it is
              illegal to do so. I am responsible to ensure that the medicine is sent to a secure address when shipped to me,
              and I
              must control any medicine that I receive
            </li>
            <li style="font-size: 14px; margin-bottom: 10px;color: #000000; display: block;">
              I understand that, for purposes of an audit, the Genentech Patient Foundation may ask me for a copy of my IRS
              1040 form or other proof of income
            </li>
          </ul>
        </div>
    
      </div>
    
    
      <!-- <div style="margin: 20px 0px;"> -->
      <div>
        <div style="display:flex; justify-content: space-between; margin: 0px 30px; padding-bottom: 10px;">
          <div>
            <h3
              style="font-family: "Roboto", sans-serif; font-size: 12px; letter-spacing: 0px; line-height: 27px; color: #005596; font-weight: bold; margin-bottom: 10px;">
              PATIENT CONSENT FORM</h3>
            <img src="images/logo.png" style="width: 200px;" />
          </div>
          <div style="text-align: right;">
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Genentech-Access.com</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Phone: <span style="color: #000;">(866) 422-2377 </span>&nbsp;&nbsp;
              Fax: <span style="color: #000;">(866) 480-7762</span></p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500; margin-bottom: 5px;">
              6 a.m.–5 p.m. (PT) M-F</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              M-US-00002802(v2.0)</p>
          </div>
        </div>
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px;">
          <h2 style="font-size: 20px; color: #ffffff;font-weight: 500; margin: 0px;">Authorization to Use and Disclose
            Personal Information</h2>
        </div>
    
        <div style="margin: 0px 30px; padding-top: 10px;">
          <p style="font-size: 14px;  color: #292829;">Authorization to Use and Disclose Personal Information
            I authorize my physician(s) and their staff, pharmacies, and health insurance plan (my “health care providers”)
            to share my personal information, which may include contact information, demographic information, financial
            information, and information related to my medical condition, treatments, and health insurance and benefits,
            with
            Genentech, Genentech Patient Foundation, and their respective partners, affiliates, subcontractors, and agents
            (together, “Genentech”). I authorize Genentech to receive, use, and share my personal information in order to
            provide
            me with access to the products, services, and programs described on this form, which may include the following:
          </p>
        </div>
        <div style="margin: 0px 30px;;">
          <ul style="padding-left: 25px; margin-bottom: 0px; margin-top: 10px;" class="x-list">
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              Working with my health insurance plan to understand or verify coverage for Genentech products
            </li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              Applying to the Genentech Patient Foundation
            </li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">Determining my eligibility for
              and facilitating enrollment into financial assistance services if I’m eligible, including
              co-pay assistance</li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">Coordinating my prescription
              through a pharmacy, infusion site and/or health care provider’s office. This
              includes contacting me to discuss my coverage, costs and eligibility for assistance and other program
              administration purposes</li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">Facilitating my access to
              Genentech products</li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">Ensuring quality and safety and
              improving our products and services</li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">Contacting me by mail, e-mail,
              telephone calls and text messages at the number(s) and address(es) provided for
              non-marketing purposes</li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">If I agree to the
              <b>optional</b> Consent for Patient Resources and Information, providing me with optional disease
              information and marketing material about products, services and programs offered by Genentech, its partners
              and their respective affiliates. This is not required to enroll into Genentech Access Solutions services
            </li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">If I agree to the
              <b>optional</b> Telephone Consumer Protection Act (TCPA) Consent, contacting me by autodialed calls
              and/or text messages at the phone number(s) I have provided for marketing purposes. This is not required to
              enroll into Genentech Access Solutions services
            </li>
          </ul>
        </div>
    
        <div style="margin: 0px 30px; padding-top: 10px;">
          <p style="font-size: 14px;  color: #292829;">I understand that Genentech may also share my personal information
            for the purposes described on this
            authorization with my health care providers, service providers, and any individual I may designate as an
            alternate
            contact. I understand that my pharmacy may receive payment or other remuneration for disclosing my personal
            information pursuant to this authorization. I can choose not to sign this authorization, but Genentech will not
            be able
            to provide the services to me without it. However, my health care providers may not condition either my
            treatment or
            my payment, enrollment, or eligibility for benefits on signing this authorization.</p>
        </div>
    
        <div style="margin: 0px 30px;;">
          <p style="font-size: 14px;  color: #292829; padding-top: 10px;">I also understand and agree that:</p>
          <ul style="padding-left: 25px; margin-bottom: 0px; margin-top: 5px;" class="x-list">
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              This authorization is valid for 6 years from the date I sign or the date I last enrolled, whichever comes
              first,
              unless a shorter period is required by law, or I revoke it earlier </li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              My personal information released under this authorization may no longer be protected by state and federal law,
              including the Health Insurance Portability and Accountability Act (HIPAA). However, Genentech will only use
              and
              share my personal information for the purposes stated on this authorization or as otherwise permitted by law
            </li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              I have the right to revoke (cancel) this authorization at any time by submitting a written notice to:
              Genentech
              Access Solutions, 1 DNA Way, South San Francisco, CA 94080-4990. If I revoke this authorization, I will no
              longer
              be eligible for the services described. If a health care provider is disclosing my personal information to
              Genentech
              on an authorized, ongoing basis, my revocation will be effective with respect to such health care provider
              when they receive notice of my revocation. My revocation will not impact uses and disclosures of my personal
              information that have already occurred in reliance on this authorization
            </li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">Coordinating my prescription
              through a pharmacy, infusion site and/or health care provider’s office. This
              includes contacting me to discuss my coverage, costs and eligibility for assistance and other program
              administration purposes</li>
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              More information on my privacy rights, including specific rights I may have as a resident of certain states,
              like
              California, can be found in Genentech’s privacy policy <b>(www.gene.com/privacy-policy)</b> </li>
    
            <li style="font-size: 14px; margin-bottom: 5px;color: #000000; display: block;">
              I have a right to receive a copy of this authorization </li>
    
          </ul>
        </div>
    
    
    
      </div>
    
    
      <div>
        <div style="display:flex; justify-content: space-between; margin: 0px 30px; padding-bottom: 10px;">
          <div>
            <h3
              style="font-family: "Roboto", sans-serif; font-size: 12px; letter-spacing: 0px; line-height: 27px; color: #005596; font-weight: bold; margin-bottom: 10px;">
              PATIENT CONSENT FORM</h3>
            <img src="images/logo.png" style="width: 200px;" />
          </div>
          <div style="text-align: right;">
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Genentech-Access.com</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              Phone: <span style="color: #000;">(866) 422-2377 </span>&nbsp;&nbsp;
              Fax: <span style="color: #000;">(866) 480-7762</span></p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500; margin-bottom: 5px;">
              6 a.m.–5 p.m. (PT) M-F</p>
            <p
              style="font-size: 14px; line-height: 1.5; color: #005596; font-family: "Roboto", sans-serif; font-weight: 500;">
              M-US-00002802(v2.0)</p>
          </div>
        </div>
    
        <div style="height: 32px; background-color: #005596; display: flex; align-items: center; padding-left: 30px;">
          <h2 style="font-size: 18px; color: #ffffff;font-weight: 500; margin: 0px;">
            Patient Information (to be completed by patient or their legally authorized representative)
          </h2>
        </div>
    
        <div style="margin: 0px 30px;">
          <p style="display: flex;justify-content: space-evenly; width: 100%;">
            <span style="color: #ed1d24; font-size: 18px; line-height: 29px; width: 15%;font-weight: 500;">*First
              name:</span>
            <span  style="width: 45%; height: 25px; border-top:0px; border-left: 0px; margin-right: 10px; ">' . htmlspecialchars($fname) . '  </span>
            <span style="color: #ed1d24; font-size: 18px; line-height: 29px; width: 15%;font-weight: 500;">*Last
              name:</span>
              <span style="width: 45%;height: 25px; border-top:0px; border-left: 0px;" > ' . htmlspecialchars($lname) . '</span>
          </p>
    
          <p style="display: flex; justify-content: space-between; width: 100%;">
            <span style="color: #000000; font-size: 18px; line-height: 29px; font-weight: 400;">Home phone:</span>                
              <span  style="display: flex; width: 35%; height: 25px; " > ' . htmlspecialchars($phone_home) . '
            </span>
            <span style="color: #000000; font-size: 18px; line-height: 29px; font-weight: 400;">Cell phone:</span>
           
              <span  style="display: flex; width: 35%; height: 25px;" > ' . htmlspecialchars($phone_cell) . '
            </span>
          </p>
    
          <p style="display: flex;justify-content: space-between; width: 100%;">
            <span style="color: #000000; font-size: 18px; line-height: 29px; width: 43%;font-weight: 400; position: relative;">  ' . $leaveSymbol . '
              OK to leave a detailed message?
              
            </span>
            

            <span style="color: #000000; font-size: 18px; line-height: 29px; ">Date of birth<span style="font-size: 14px;">
                (MM/DD/YYYY):</span></span>
                <span
              style="width: 25%;height: 25px; border-top:0px; border-left: 0px;" > ' . htmlspecialchars($dob) . '</span>
          </p>
    
          <p style="display: flex;justify-content: space-between; width: 100%;">
            <span style="color: #000000; font-size: 18px; line-height: 29px; ">Email:</span>
            <span 
              style="width: 20%;height: 25px;  border-top:0px; border-left: 0px;" > ' . htmlspecialchars($email) . '</span>
    
            <span style="color: #000000; font-size: 18px; line-height: 29px; ">Preferred language: </span>
            <span style="display: flex; align-items: center; position: relative;">
              <span 
                style="height: 20px;border-top:0px; border-left: 0px;" > ' . htmlspecialchars($preferred_language) . ' </span>
               
            </span>
           
            <span style="color: #000000; font-size: 18px; line-height: 29px; ">Other language:</span>
            <span 
              style="height: 25px; width: 15%; border-top:0px; border-left: 0px;" />' . htmlspecialchars($other_language) . '  </span>
          </p>
    
          <p style="display: flex; width: 100%;">
            <span style="color: #000000; font-size: 18px; line-height: 29px; display: flex;"><span
                style="color: #005596; padding-right: 5px;">Alternate Contact (optional) </span> Full name:</span>
            <span  style="width: 57%; height: 25px;border-top:0px; border-left: 0px;" > ' . htmlspecialchars($alter_contact) . '</span>
          </p>
    
    
          <p style="display: flex; justify-content: space-between; width: 100%;">
            <span style="color: #000000; font-size: 18px; line-height: 37px; font-weight: 400;">Relationship:</span>
            <span style="width: 40%; height: 25px; border-top:0px; border-left: 0px; " > ' . htmlspecialchars($relationship) . ' </span>
    
            <span style="color: #000000; font-size: 18px; line-height: 37px; font-weight: 400;">phone:</span>
          
              
              <span style="height: 22px;  border:0px; " >
              ' . htmlspecialchars($p_phone) . '
            </span>
          </p>
        </div>
    
        <div style="margin: 0px 30px; display: flex;  border: 2px solid #005596; margin-bottom: 5px;">
          <div style="background-color: #005596; width: 8%; position: relative;">
            <div style="position: absolute; left: 35%;  top: 40%; color: #ffffff; font-size: 25px; margin-right: 5px;">
              <span> 1</span>
            </div>
          </div>
          <div style="padding: 5px; width: 92%;">
            <p style="color: #005596; font-size: 14px;">Financial Eligibility: Complete <b>only</b> if you are applying to
              the Genentech Patient Foundation</p>
            <p style="color: #000000; font-size: 14px;">By completing this section, I am agreeing to the Terms and
              Conditions of the Genentech Patient Foundation outlined on page 1.</p>
    
            <p style="display: flex;justify-content: space-between; width: 100%;">
              <span style="color: #000000; font-size: 14px; line-height: 29px; font-weight: 400;">Household size (including
                you):</span>
              <span  style="width: 15%; height: 25px; border-top:0px; border-left: 0px; margin-right: 10px; " > ' . htmlspecialchars($household_size) . ' </span>
              <span style="color: #000000; font-size: 16px; line-height: 29px; font-weight: 400;">Annual household
                income:</span>
              <span style="display: flex; align-items: center; position: relative;">
               
                <span  style="position: absolute; top: 9px; left: 4px; height: 15px; width: 15px; border-radius: 50%; "> ' . htmlspecialchars($annual_household_income) . ' </span>
               
            </p>
    
           
          </div>
        </div>
    
        <div style="margin: 0px 30px; display: flex;  border: 2px solid #005596; margin-bottom: 5px;">
          <div style="background-color: #005596; width: 8%; position: relative;">
            <div style="position: absolute; left: 35%;  top: 40%; color: #ffffff; font-size: 25px; margin-right: 5px;">
              <span>2</span>
            </div>
          </div>
          <div style="padding: 5px; width: 92%;">
            <p style="color: #005596; font-size: 14px;">Consent for Patient Resources and Information <b>(OPTIONAL)</b></p>
            <p style="color: #000000; font-size: 14px;">Genentech offers <b>optional</b> and free disease education and
              other material for patients. This may
              include information and marketing material about products, services and programs offered by Genentech, its
              partners and their respective affiliates. If you sign up, you may be contacted using the
              information you have provided.</p>
    
            <div style="display: flex; align-items: start; position: relative;">
              <spam  style=" font-size: 18px;  margin-right: 5px;margin-top: 7px;" > ' . $cpriSymbol . '</span>
              <span class="checkmark" style="position: absolute; top: 7px; left: 3px; height: 15px; width: 15px;
              background-color: #dee5ff;"></span>
    
              <p  style="color: #000; font-size: 14px; margin-top: 5px;">
                By checking this box, I agree to receive <b>optional</b> disease education and other material.
                I understand providing this agreement is voluntary and plays no role in getting Genentech Access
                Solutions services or my medicine. I also understand that I may opt out of receiving this information
                at any time by calling <b>(877) 436-3683</b> and that this consent will remain active unless I opt out.</p>
            </div>
            <p style="color: #005596; font-size: 14px; margin-top: 5px;">Telephone Consumer Protection Act (TCPA) Consent
              <b>(OPTIONAL)</b></p>
            <div style="display: flex; align-items: start; position: relative;">
             
              <span  style="position: absolute; top: 7px; left: 3px; height: 15px; width: 15px;">  ' . $tcpacSymbol . '</span> 
    
              <p  style="color: #000; font-size: 14px; margin-top: 5px;">
                By checking this box, I consent to receive autodialed marketing calls and text messages from and
                on behalf of Genentech at the phone number(s) I have provided. I understand that consent is not a
                requirement of any purchase or enrollment. Message frequency may vary. Message and data rates
                may apply. I may opt out at any time by texting STOP or calling <b>(877) GENENTECH</b>/(877) 436-3683.</p>
            </div>
          </div>
        </div>
    
        <div style="margin: 0px 30px; display: flex;  border-top: 2px solid #005596; border-left: 2px solid #005596;
        border-right: 2px solid #005596; border-bottom: 0px solid #005596; ">
          <div style="background-color: #005596; width: 8%; position: relative;">
            <div style="position: absolute; left: 35%;  top: 40%; color: #ffffff; font-size: 25px; margin-right: 5px;">
              <span>3</span>
            </div>
          </div>
          <div style="padding: 5px; width: 92%;">
            <p style="color: #005596; font-size: 14px;">By signing this form, I acknowledge that I have provided accurate
              and complete information
              and understand and agree to the terms of this form. My signature certifies that I have read,
              understood, and agree to the release and use of my personal information pursuant to the
              Authorization to Use and Disclose Personal Information and as otherwise stated on this form.</p>
          </div>
        </div>
    
        <div style="margin: 0px 30px; display: flex;  border-top: 0px solid #005596; border-left: 2px solid #005596;
        border-right: 2px solid #005596; border-bottom: 2px solid #005596;  margin-bottom: 5px;">
          <div style="background-color: #e2e5b7; width: 8%; position: relative;">
            <div
              style=" 
              position: absolute; left: 30%; bottom: 0; transform: rotate(-90deg);  transform-origin: 0 0;color: #005596; font-size: 18px; margin-right: 5px; font-weight: 500;">
              <span>REQUIRED</span>
            </div>
          </div>
          <div style="padding: 5px 5px 5px 0px; width: 92%;">
            <div style="display: flex;">
              <p style="position: relative; display: flex; align-self: center; width: 20%;">
                <img src="images/icon6.png" style="position: relative; width: 130px; height: 60px;" />
                <span style="position: absolute; left: 0; top:10px; color: #ffffff; font-weight: 500; font-size: 17px; padding-left: 5px;">Sign
                  and <br /> date here</span>
              </p>
              <div style="width: 80%; margin-left: 5px;">
                <span style="width: 96%; height: 25px; border-top: 0px;  border-left: 0px;         margin-right: 10px;" > ' . htmlspecialchars($sign) . '</span>
                <p style="color: #ed1d24; font-size: 16px;  font-weight: 500; letter-spacing: 0px;
                margin: 0;  padding: 0;  ">  *Signature of Patient/Legally Authorized Representative</p>
                <p style="color: #000;
              font-size: 14px;
              font-weight: 500;
            ">(A parent or guardian must sign for patients under 18 years of age)</p>
              </div>
              <div style="width: 20%;">
                <span style="display: flex; width: 100%; height: 25px;  border-bottom: 1px solid #000000;">
                 
                <span style="height: 22px;  border:0px; width: 50%;" > ' . htmlspecialchars($date_signed) . '</span>
                </span>
                <p style="color: #ed1d24; font-size: 18px;  font-weight: 500;">*Date signed</p>
                <p style="color: #000; font-size: 15px;  font-weight: 500;letter-spacing: 0px; ">(MM/DD/YYYY)</p>
              </div>
            </div>
    
            <div style="display: flex; margin-top: 10px;">
              <p style="position: relative; display: flex; align-self: center; width: 20%;">
                <img src="images/icon6.png" style="position: relative; width: 130px; height: 60px;" />
                <span style="position: absolute; left: 0; top:10px; color: #ffffff; font-size: 17px; padding-left: 5px;">
                  <span style=" font-weight: 500; "> Person signing </span><br /> <span>(if not patient) </span>
              </p>
              <div style="width: 26%; margin-right: 10px;">
                <span  style="width: 100%;height: 25px;border-top: 0px; border-left: 0px; margin-right: 10px; " > ' . htmlspecialchars($p_fname) . ' </span>
    
                <p style="color: #000;  font-size: 16px; font-weight: 400;text-align: center;">Print first name </p>
              </div>
    
              <div style="width: 26%; margin-right: 10px;">
                <span  style="width: 100%; height: 25px;border-top: 0px; border-left: 0px; margin-right: 10px; " > ' . htmlspecialchars($p_lname) . '</span>
    
                <p style="color: #000;
              font-size: 16px;
              font-weight: 400;
              text-align: center;
            ">Print last name </p>
              </div>
    
    
              <div style="width: 26%; margin-right: 5px;">
                <span style="width: 100%; height: 25px; border-top: 0px; border-left: 0px; margin-right: 10px; " > ' . htmlspecialchars($r_patient) . '</span>
    
                <p style="color: #000; font-size: 16px; font-weight: 400; text-align: center;            ">Relationship to patient </p>
              </div>
            </div>
    
    
          </div>
        </div>
    
    
        <div style="margin: 0px 30px;">
          <p style="color: #000; font-size: 16px;">
            <span style="color: #005596; font-size: 16px;"><b>Once this page (3/3) has been completed,</b></span>
             please text a photo of the page to <b>(650) 877-1111</b> or fax to
           <b>(866) 480-7762</b>. You can also complete this form online at <b>Genentech-Access.com/PatientConsent.</b></p>
          <p style="color: #000; font-size: 14px;">   
            If this is an electronic consent, you understand that by typing your name and the date above and submitting, or taking a picture
            and sending to us, that you are providing your consent electronically and that it has the same force and effect as if you were
            signing in person on paper. Genentech reserves the right to rescind, revoke or amend the program without notice at any time.</p>
        </div>
      </div>
    
    </body>
  </html>' ;

$mpdf->WriteHTML($html);

try {
    // Output the PDF and save it to the specified file location
    $mpdf->Output($fileLocation, 'F'); // 'F' saves the PDF to a file

    // Provide a download link for the user
    echo 'Update and PDF : <a href="' . $fileLocation . '" download>' . $fileName . '</a>';
} catch (\Mpdf\MpdfException $e) {
    echo 'An error occurred: ' . $e->getMessage();
}
}
// Your HTML content for the PDF
$html = '<html>Your HTML content goes here</html>';

// Specify the file location where you want to save the PDF with the patient ID in the file name
$fileName = 'patient_consent_form_' . $patient_id . '.pdf';
// $fileLocation = '../../../sites/default/documents/patient_consent_form/' . $fileName;
// $documentRoot = $_SERVER['DOCUMENT_ROOT'];
// $fullPath = '/sites/default/documents/patient_consent_form/';
// $fileLocation = $documentRoot . $fullPath . $fileName;
$documentRoot = $_SERVER['DOCUMENT_ROOT'];
$file_location = '/sites/default/documents/patient_consent_form/'; // Define the file location
$serverFileLocation = $documentRoot . $file_location . $fileName;
$mpdf->Output($serverFileLocation, 'F'); // 'F' saves the PDF to a file

// Now you can use $fullPath as your file location

try {
    // Add headers and footers
    $mpdf->SetHeader('Welcome to all'); // Set your header content
    $mpdf->SetFooter('Footer text'); // Set your footer content

    // Write HTML content to the PDF
    $mpdf->WriteHTML($html);

    // Output the PDF to the browser
    $mpdf->Output($fileLocation, 'I'); // 'I' sends the PDF inline to the browser
    // Update the database with file_location and file_name
    // if (isset($_SESSION['pid'])) {
    //   $patient_id = $_SESSION['pid'];
    //   $update_file_query = "UPDATE patient_consent_form SET file_location = ?, file_name = ? WHERE patient_id = ?";
    //   $update_file_params = array($fileLocation, $fileName, $patient_id);
    //   sqlStatement($update_file_query, $update_file_params);

      if (isset($_SESSION['pid'])) {
        $patient_id = $_SESSION['pid'];
        $update_file_query = "UPDATE patient_consent_form SET file_location = ?, file_name = ? WHERE patient_id = ?";
        $update_file_params = array($file_location . $fileName, $fileName, $patient_id);
        sqlStatement($update_file_query, $update_file_params);
    }
    exit;
  }
 catch (\Mpdf\MpdfException $e) {
  echo 'An error occurred: ' . $e->getMessage();
}
exit;

?>
<!DOCTYPE html>
<html lang="en">

<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $fname; ?> Patient Consent Form (<?php echo $patient_id; ?>)</title>
    <style>
    /* Add CSS styles here */
    </style>
</head>

<body>
    <!--  HTML content goes here -->
</body>

</html>

